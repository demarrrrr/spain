const sliceArr = (arr: unknown[], from: number, to: number) => arr.slice(from, to)

export default sliceArr
